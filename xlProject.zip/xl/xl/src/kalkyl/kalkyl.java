package kalkyl;

public class kalkyl {
	
	
	private String[][]matrix;
	
	
	public kalkyl(int row, int col) {
		matrix = new String[row][col];
	}
	
	
	
	public void update(int row, int col, String value) {
		
	}
	
	
}
