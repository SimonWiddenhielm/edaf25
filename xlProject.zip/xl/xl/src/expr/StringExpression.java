package expr;

public class StringExpression extends Expr {

	@Override
	public String toString(int prec) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double value(Environment env) {
		// TODO Auto-generated method stub
		return 0;
	}

}
