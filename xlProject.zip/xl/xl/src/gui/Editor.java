package gui;

import java.awt.Color;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JTextField;

public class Editor extends JTextField implements Observer {
	
	private CurrentLabel current; //Current "slot" chosen, chosen upon MouseEvent-> Mouseclick, the expression typed in the editor class(JTextField) from keyboard will be a value or equation 
	private SlotLabels grid; //   (compiled as of either another slot or combination of 2 or more ) or comment. This expression is dipslayed in the  currentLabel(marked.YELLOW) obj
    public Editor(CurrentLabel current, SlotLabels grid) {
    	
    	this.current=current;
    	this.grid=grid;
    	
        setBackground(Color.WHITE);
    }
	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		
	}
    
    
    
    
    
    
    
}