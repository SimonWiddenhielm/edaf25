package gui;

import java.awt.Color;

public class CurrentLabel extends ColoredLabel {
    public CurrentLabel() {
        super("A1", Color.WHITE);
        
    }
    
    public void changeText(String input) {
    	setText(input);
    }
}